Batch - A | Group - 4

---------------------

In this folder, we have the ppt, report (as pdf) and 3 folders namely, BlowFish, TwoFish and UI_FileEncryption_and_UserInput_Encrypted_ClientServerModel.


The Folder "BlowFish" contains the implementations of Blowfish Algorithm in Python, Java and C++.
The Folder "TwoFish" contains the implementations of Twofish Algorithm in Python, Java and C++.
The UI Folder contains the implementation of File And Text (Input) Encryption Model based on Blowfish and Twofish Algorithms. You need to execute just the "file_encryption_app_clientserver.py" script. All the necessary instructions are available in a 'Readme.txt' file in that folder.