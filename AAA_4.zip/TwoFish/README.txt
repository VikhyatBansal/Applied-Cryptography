To run two fish,

Python --> Go to Final Term Folder,then go to python folder, open twofish.py and RUN

Java --> Open main.java and Run it as it is

C++ --> Go to Final Term Folder, go to C++ folder, compile twofish.cpp and then run the compiled file

